create
    definer = kang@`%` function make_search_pattern(input text) returns text
BEGIN
    DECLARE i INT DEFAULT 1;
    DECLARE len INT DEFAULT CHAR_LENGTH(input);
    DECLARE c CHAR(1);
    DECLARE pattern TEXT DEFAULT '';

    WHILE i <= len DO
            SET c = SUBSTRING(input, i, 1);

            -- 초성 여부에 따라 유니코드 범위 처리
            IF c = 'ㄱ' THEN
                SET pattern = CONCAT(pattern, '[가-깋]');
            ELSEIF c = 'ㄲ' THEN
                SET pattern = CONCAT(pattern, '[까-낗]');
            ELSEIF c = 'ㄴ' THEN
                SET pattern = CONCAT(pattern, '[나-닣]');
            ELSEIF c = 'ㄷ' THEN
                SET pattern = CONCAT(pattern, '[다-딯]');
            ELSEIF c = 'ㄸ' THEN
                SET pattern = CONCAT(pattern, '[따-띻]');
            ELSEIF c = 'ㄹ' THEN
                SET pattern = CONCAT(pattern, '[라-맇]');
            ELSEIF c = 'ㅁ' THEN
                SET pattern = CONCAT(pattern, '[마-밓]');
            ELSEIF c = 'ㅂ' THEN
                SET pattern = CONCAT(pattern, '[바-빟]');
            ELSEIF c = 'ㅃ' THEN
                SET pattern = CONCAT(pattern, '[빠-삫]');
            ELSEIF c = 'ㅅ' THEN
                SET pattern = CONCAT(pattern, '[사-싷]');
            ELSEIF c = 'ㅆ' THEN
                SET pattern = CONCAT(pattern, '[싸-앃]');
            ELSEIF c = 'ㅇ' THEN
                SET pattern = CONCAT(pattern, '[아-잏]');
            ELSEIF c = 'ㅈ' THEN
                SET pattern = CONCAT(pattern, '[자-짛]');
            ELSEIF c = 'ㅉ' THEN
                SET pattern = CONCAT(pattern, '[짜-찧]');
            ELSEIF c = 'ㅊ' THEN
                SET pattern = CONCAT(pattern, '[차-칳]');
            ELSEIF c = 'ㅋ' THEN
                SET pattern = CONCAT(pattern, '[카-킿]');
            ELSEIF c = 'ㅌ' THEN
                SET pattern = CONCAT(pattern, '[타-팋]');
            ELSEIF c = 'ㅍ' THEN
                SET pattern = CONCAT(pattern, '[파-핗]');
            ELSEIF c = 'ㅎ' THEN
                SET pattern = CONCAT(pattern, '[하-힣]');
            ELSE
                -- 완성형 한글 또는 기타 문자 그대로 사용
                SET pattern = CONCAT(pattern, c);
            END IF;

            SET i = i + 1;
        END WHILE;

    RETURN pattern;
END;

